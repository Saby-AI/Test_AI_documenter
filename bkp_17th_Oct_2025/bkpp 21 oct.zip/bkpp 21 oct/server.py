"""Azure AI Agent Service MCP Server"""

import logging
import os
import threading
import time
from pathlib import Path

from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential
from dotenv import load_dotenv
from fastapi import Response
from mcp.server.fastmcp import FastMCP
import requests
import base64
from urllib.parse import urlparse
import sys
from importlib import util as importlib_util

# Import existing github helper functions from tools-api/code_documenter_tool if available
def _import_code_documenter_github_tools():
    """Dynamically import github_tools from the code_documenter_tool package.

    This keeps the MCP server decoupled and avoids code duplication. If the
    import fails, fall back to None and let the wrapper functions return
    an informative error.
    """
    try:
        # Ensure the path to tools-api/code_documenter_tool is on sys.path
        repo_root = Path(__file__).resolve().parents[1]
        candidate = repo_root / "tools-api" / "code_documenter_tool"
        if str(candidate) not in sys.path:
            sys.path.insert(0, str(candidate))

        import github_tools as gt
        return gt
    except Exception:
        return None


_CD_GITHUB_TOOLS = _import_code_documenter_github_tools()

# Load environment variables from the mcp-server directory
env_path = os.path.join(os.path.dirname(__file__), ".env")
load_dotenv(env_path)
# load_dotenv()  # Load from current directory as fallback

# Optional URL of deployed tools API (e.g. https://code-documenter-api.../)
CODE_DOCUMENTER_API_URL = os.getenv("CODE_DOCUMENTER_API_URL", "").strip().rstrip('/')

mcp = FastMCP(
    name="Encora AIVA MCP Server",
    instructions="This MCP server integrates with Azure AI Agent Service to handle Encora AIVA agentic workflows.",
)

PROJECT_ENDPOINT_STRING = os.getenv("PROJECT_ENDPOINT_STRING", "")

ACTIVE_STATUSES = {"queued", "in_progress", "requires_action"}
TERMINAL_FAILURE_STATUSES = {"failed"}
DEFAULT_POLL_INTERVAL = 1.0  # seconds
DEFAULT_TIMEOUT = float(
    os.getenv("AGENT_RUN_TIMEOUT", "180")
)  # seconds; configurable via env


def _invoke_agent(
    agent_env_var: str,
    prompt: str,
    *,
    friendly_name: str | None = None,
    timeout: float = DEFAULT_TIMEOUT,
    poll_interval: float = DEFAULT_POLL_INTERVAL,
) -> str:
    """Generic Azure Agent runner used by all MCP tool wrappers.

    Args:
        agent_env_var: Environment variable name that stores the agent ID.
        prompt: User-provided prompt/content.
        friendly_name: Human label used in error messages (defaults to env var simplified).
        timeout: Max seconds to wait for a run to reach a terminal state.
        poll_interval: Sleep interval between status polls.

    Returns:
        str: Final text response (may be empty) or a formatted error message.
    """
    agent_id = os.getenv(agent_env_var, "").strip()
    label = friendly_name or agent_env_var.replace("_", " ").title()
    if not PROJECT_ENDPOINT_STRING:
        return "⚠️ Configuration error: PROJECT_ENDPOINT_STRING not set"
    if not agent_id:
        return f"⚠️ Configuration error: {agent_env_var} not set"

    start_time = time.time()

    try:
        ai_client = AIProjectClient(
            endpoint=PROJECT_ENDPOINT_STRING, credential=DefaultAzureCredential()
        )
        with ai_client:
            thread = ai_client.agents.threads.create()
            ai_client.agents.messages.create(
                thread_id=thread.id, role="user", content=prompt
            )
            run = ai_client.agents.runs.create_and_process(
                thread_id=thread.id, agent_id=agent_id
            )

            # Some backends may already return a terminal run from create_and_process
            while getattr(run, "status", None) in ACTIVE_STATUSES:
                if time.time() - start_time > timeout:
                    return f"⚠️ {label} timed out after {int(timeout)}s"
                time.sleep(poll_interval)
                run = ai_client.agents.runs.get(thread_id=run.thread_id, run_id=run.id)

            status = getattr(run, "status", "unknown")
            if status in TERMINAL_FAILURE_STATUSES:
                last_error = getattr(run, "last_error", "unknown error")
                return f"❌ {label} run failed: {last_error}"

            # Fetch latest message
            messages = ai_client.agents.messages.list(
                thread_id=thread.id, order="desc", limit=1
            )
            msg = next(iter(messages), None)
            if msg and getattr(msg, "text_messages", None):
                try:
                    return msg.text_messages[-1].text.value  # type: ignore[attr-defined]
                except Exception:
                    return "⚠️ Response parsing error: unexpected message structure"
            return "⚠️ No textual response produced"
    except (
        Exception
    ) as e:  # Broad catch to preserve existing contract of returning a string
        return f"⚠️ Error invoking {label}: {e}"  # Do not expose stack for now (could log separately)


@mcp.tool()
def run_code_reviewer_agent(prompt: str) -> str:
    """
    Forward a user's natural language request to the Code Reviewer Agent.

    This tool passes the given code snippet directly to the preconfigured agent. The agent is responsible
    for review the code with the help of provided guidelines and return review comments with refactored code.

    Args:
        prompt (str): user prompt with code snippet

    Returns:
        str: The final response from the Code Reviewer Agent, or an error message if the run fails.
    """
    return _invoke_agent(
        "CODE_REVIEW_AGENT_ID", prompt, friendly_name="Code Reviewer Agent"
    )


@mcp.tool()
def run_planner_srd_agent(prompt: str) -> str:
    """
    Forward a user's natural language request to the Coding Planner Agent.

    This agent generates a comprehensive and actionable coding plan based on user stories
    retrieved from Jira and the technical stack provided by the user.

    The resulting development plan is designed to be fed to coding agents (such as Claude Code) to
    develop new functionality, enabling higher-quality code generation compared to generic prompts.

    Workflow:
    - Extracts the project key from the user's prompt.
    - Uses JiraTool to fetch user stories for the specified project key.
    - Requests the technical stack from the user if not provided.
    - Analyzes each user story (summary, description, acceptance criteria) to identify and expand coding tasks.
    - Considers non-functional requirements such as security, error handling, logging, and scalability.
    - Produces a detailed coding plan in markdown format for each user story.

    Error Handling:
    - If the project key is missing or invalid, prompts the user or returns an error.
    - If no user stories are found, returns a corresponding message.
    - If the tech stack is missing, requests it from the user and does not generate a coding plan until provided.

    Args:
        prompt (str): User request to generate a coding plan for a specific project.

    Returns:
        str: The detailed coding plan in markdown format, or an error message if there is a problem accessing
        the Jira project or required information is missing.
    """
    return _invoke_agent(
        "PLANNER_SRD_AGENT_ID", prompt, friendly_name="Coding Planner Agent"
    )


@mcp.tool()
def run_test_case_generator_agent(prompt: str) -> str:
    """
    Forwards a user's natural language request to the QA Manual Test Case Generator Agent.

    This tool generates comprehensive manual test cases from business requirements and optional system context.
    Your prompt must clearly specify:
      - The business requirements to be tested (required)
      - Any relevant system context (optional)

    Response Format:
    The agent returns a Markdown string with the generated test scenario. Each test scenario includes:
        Scenario ID: ID.
        Scenario Name: Concise name.
        Description: A short explanation of the scenario and what is being validated.
        Scope: The exact part of the business requirement being validated.
        Priority: P0 (Critical), P1 (High), P2 (Medium), P3 (Low) based on business impact.
        Expected Result: What the outcome must be for the scenario to pass.
    Args:
        prompt (str): A clear, specific request including business requirements and additional context.

     Returns:
        str: The final response from the QA Test Case Generator Agent with the generate test scenarios, or an error message if the run fails.
    """
    return _invoke_agent(
        "QA_SCENARIO_AGENT_ID",
        prompt,
        friendly_name="QA Manual Test Case Generator Agent",
    )


@mcp.tool()
def run_test_case_generator_gherkin_agent(prompt: str) -> str:
    """
    Forwards a user's natural language request to the QA Gherkin Test Case Generator Agent.

    This tool generates comprehensive manual test cases from business requirements and optional system context.
    Your prompt must clearly specify:
      - The business requirements to be tested (required)
      - Any relevant system context (optional)

    Response Format:
    The agent returns a URL to download a `.feature` file with the generated test cases in Gherkin format.
    Args:
        prompt (str): A clear, specific request including business requirements and additional context.

     Returns:
        str: The final response from the QA Gherkin Test Case Generator Agent with the URL to download the .feature file that holds the generated test cases, or an error message if the run fails.
    """
    return _invoke_agent(
        "QA_GHERKIN_AGENT_ID",
        prompt,
        friendly_name="QA Gherkin Test Case Generator Agent",
    )


@mcp.tool()
def run_project_status_reporter_agent(prompt: str) -> str:
    """
    Forwards a user's natural language request to the Project Status Reporter Agent.

    This tool generates a comprehensive project status report in HTML format from Jira data.
    Your prompt must clearly specify:
      - The Jira project and sprint to report on (required)
      - Any specific sections or data points to include (optional)
    """
    return _invoke_agent(
        "PROJECT_STATUS_REPORTER_AGENT_ID",
        prompt,
        friendly_name="Project Status Reporter Agent",
    )


@mcp.tool()
def run_code_documenter_agent(prompt: str) -> str:
    """
    Forward a user's natural language request to the Code Documenter Agent.

    This tool passes the given code or project request directly to the preconfigured documenter agent.
    The agent is responsible for generating comprehensive documentation including README files,
    API documentation, and inline code comments based on provided guidelines and best practices.

    Args:
        prompt (str): user prompt with code snippet, project details, or documentation requirements

    Returns:
        str: The final response from the Code Documenter Agent, or an error message if the run fails.
    """
    return _invoke_agent(
        "CODE_DOCUMENTER_AGENT_ID", prompt, friendly_name="Code Documenter Agent"
    )


@mcp.tool()
def run_test_script_generation_agent(prompt: str) -> str:
    """
    Forward a user's request to the Test Script Generation Agent.

    This tool passes the given prompt directly to the preconfigured 'test script generation' agent.
    The agent task is to create/generate test cases using the given requirements.
    The final response is the test source code.

    Args:
        prompt (str): A natural language request from the user including steps to generate tests:

    Returns:
        str: The Generated test sources links.
    """
    return _invoke_agent(
        "TEST_SCRIPT_GENERATION_AGENT_ID", prompt, friendly_name="Test Generation Agent"
    )


# -------------------------
# Direct GitHub token-backed tools
# These allow clients to call GitHub APIs directly via the MCP server
# using a GITHUB_TOKEN set in the mcp-server/.env file, bypassing
# any external GitKraken MCP integration.
# -------------------------

@mcp.tool()
def fetch_file_from_github(github_blob_url: str) -> str:
    """Wrapper MCP tool — fetch file content using shared `github_tools.fetch_github_file_content`.

    Accepts a GitHub blob URL: https://github.com/owner/repo/blob/{branch}/path/to/file
    """
    # If a deployed tools API URL is configured, prefer calling it (remote tools)
    if CODE_DOCUMENTER_API_URL:
        try:
            endpoint = f"{CODE_DOCUMENTER_API_URL}/fetch_file_content"
            resp = requests.post(endpoint, json={"file_path": github_blob_url}, timeout=30)
            if resp.status_code == 200:
                j = resp.json()
                if j.get("success"):
                    return j.get("result", "")
                return f"⚠️ Tools API error: {j.get('error') or j.get('result') or str(j)}"
            return f"⚠️ Tools API HTTP error: {resp.status_code} {resp.text}"
        except Exception as e:
            # If remote call fails, fall back to local shared module if available
            if not _CD_GITHUB_TOOLS:
                return f"⚠️ Error contacting Tools API and local github_tools not available: {e}"
            # otherwise continue to local fallback below

    # Local fallback: call shared github_tools in repo
    if not _CD_GITHUB_TOOLS:
        return "⚠️ GitHub helper module not available in tools-api/code_documenter_tool."

    try:
        owner, repo, path, branch = _CD_GITHUB_TOOLS.extract_github_info_from_url(github_blob_url)
        if not owner:
            return "⚠️ Could not parse GitHub URL. Provide a URL like: https://github.com/owner/repo/blob/branch/path"
        return _CD_GITHUB_TOOLS.fetch_github_file_content(owner, repo, path, branch)
    except Exception as e:
        return f"⚠️ Error fetching file via shared github_tools: {e}"


@mcp.tool()
def save_file_to_github(github_blob_url: str, content: str, commit_message: str = "Update via MCP server") -> str:
    """Wrapper MCP tool — save/update file using shared `github_tools.commit_to_github`.

    Accepts a GitHub blob URL: https://github.com/owner/repo/blob/{branch}/path/to/file
    """
    # If a deployed tools API URL is configured, prefer calling it (remote tools)
    if CODE_DOCUMENTER_API_URL:
        try:
            endpoint = f"{CODE_DOCUMENTER_API_URL}/save_file_to_github"
            resp = requests.post(endpoint, json={"file_path": github_blob_url, "content": content}, timeout=60)
            if resp.status_code == 200:
                j = resp.json()
                if j.get("success"):
                    return j.get("result", "File saved (tools API)")
                return f"⚠️ Tools API error: {j.get('error') or j.get('result') or str(j)}"
            return f"⚠️ Tools API HTTP error: {resp.status_code} {resp.text}"
        except Exception as e:
            # If remote call fails, fall back to local shared module if available
            if not _CD_GITHUB_TOOLS:
                return f"⚠️ Error contacting Tools API and local github_tools not available: {e}"
            # otherwise continue to local fallback below

    # Local fallback: call shared github_tools in repo
    if not _CD_GITHUB_TOOLS:
        return "⚠️ GitHub helper module not available in tools-api/code_documenter_tool."

    try:
        owner, repo, path, branch = _CD_GITHUB_TOOLS.extract_github_info_from_url(github_blob_url)
        if not owner:
            return "⚠️ Could not parse GitHub URL. Provide a URL like: https://github.com/owner/repo/blob/branch/path"
        resp = _CD_GITHUB_TOOLS.commit_to_github(owner, repo, path, content, commit_message, branch)
        if isinstance(resp, dict):
            return f"File successfully saved to GitHub: {github_blob_url}"
        return str(resp)
    except Exception as e:
        return f"⚠️ Error saving file via shared github_tools: {e}"


# === Start MCP ===
if __name__ == "__main__":
    mcp.run()
